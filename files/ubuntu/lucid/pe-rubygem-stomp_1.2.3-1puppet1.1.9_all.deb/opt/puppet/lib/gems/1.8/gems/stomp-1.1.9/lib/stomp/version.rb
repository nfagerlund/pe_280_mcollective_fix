module Stomp
  module Version  #:nodoc: all
    MAJOR = 1
    MINOR = 1
    PATCH = 9
    STRING = "#{MAJOR}.#{MINOR}.#{PATCH}"
  end
end
